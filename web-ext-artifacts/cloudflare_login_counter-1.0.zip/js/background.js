// init sync storage
(async ()=>{
	let storage = await browser.storage.sync.get()
	if(storage.success === undefined){
		await browser.storage.sync.set({success:0, fail:0})
	}
})()

browser.webRequest.onCompleted.addListener(async (details) => {
	let storage = await browser.storage.sync.get()

	if(details.statusCode===200){
		await browser.storage.sync.set({success:storage.success+1})
		console.log("success")
	}else{
		await browser.storage.sync.set({fail:storage.fail+1})
		console.log("failed")
	}
} ,{urls:["https://dash.cloudflare.com/api/v4/login"]})
